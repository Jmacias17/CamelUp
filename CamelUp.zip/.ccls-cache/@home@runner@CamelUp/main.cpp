#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>
#include "Camel"
#include "Game"
#include "Action"

int main()
{
    char c;
	cout << " Welcome to Camel Up!\n A game where camel racing betting is encouraged!\n\n";
    Game newGame;
	Action::removeTicket(0);
    cout<<"\n";
	
    int turn = 1;
    while (turn <= 5)
    {
        c = newGame.getAction();
        switch (c)
        {
            case 'A':
                cout << "Action under development\n";
				continue;
            case 'B':
                cout << "Action under development\n";
                continue;
            case 'C':
                Action::removeTicket(turn);
                Action::getToken(newGame);
                break;
            case 'D':
                cout << "Action under development\n";
                continue;
			default:
				cout<< "Error Occured \n";
        }
        turn++;
    }
  
  return 0;
}
