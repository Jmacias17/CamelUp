#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>
#include "Camel.h"

class Message
{
	public:
		static void displayActions()
		{
			cout << "----------------------------------------------------------------------\n";
		    cout << "|A. Take top betting card                                            |\n";
		    cout << "|B. Place spectator tile on track                                    |\n";
		    cout << "|C. Take 1 pyramid ticket and throw dice                             |\n";
		    cout << "|D. Bet on overall winner or loser                                   |\n";
		    cout << "----------------------------------------------------------------------\n";
		}

		static void displayCamelPositions()
		{
			Camel currCamel;
			for (int i = 1; i < 8; i++)
			{
				currCamel = Game::getCamel(i);
				cout << currCamel.getColor() << " is at " << currCamel.getPosition() << "\n"; 
			}
		}
};
	
