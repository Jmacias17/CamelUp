#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>

class Action
{
	public:
		static void getToken() 
		{
			cout << "Action under development\n";
		}

		static int removeTicket(int x)
		{
	    	int pt;
	    
	    	pt = 5 - x;
	    
	    	cout << " Pyramid Tickets left:" << pt << "\n";
	    
	    	return pt;
		}
			
};
	