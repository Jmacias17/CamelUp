#ifndef GAME_H
#define GAME_H
#include "Camel.h"
#include "Message.h"
#include <iostream>
using namespace std;
#include <cstring>
#include <ctype.h>
#include <map>
#include <string>

// This Game class includes the logic to control the aspects of the CamelUp
// game.
class Game {
  // Functions are static to only allow execution to all instances of object
  // Game. In other words there is only ONE Game.
private:
  // Camel Pieces.
  int pieces = 7;
  Camel camels[7];

public:
  Game() { this->start(); }
  void start();
  void displayCamels();
  char getAction();

  // Get the Camel in location of Camel Num in the Hash Map camels
  Camel& getCamel(int camelNum) { return camels[camelNum]; }

  void setCamels() 
  {
    for (int i = 0; i < this->pieces; i++) 
	{
      Camel newCamel(i);
      this->camels[i] = newCamel;
    }
  }

  void printCamels()
  {
	  for (int i = 0; i < this->pieces; i++)
	  {
		  cout << "Camel -> " << this->camels[i].getPosition();
	  }
  }
};

#endif