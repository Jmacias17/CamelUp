#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>

class Action
{
	public:
		static void displayWelcome() 
		{
			cout << " Welcome to Camel Up!\n A game where camel racing betting is encouraged!\n";
    		cout <<"\n";
		}

		static void displayActions()
		{
			cout << "----------------------------------------------------------------------\n";
		    cout << "|A. Take top betting card                                            |\n";
		    cout << "|B. Place spectator tile on track                                    |\n";
		    cout << "|C. Take 1 pyramid ticket and throw dice                             |\n";
		    cout << "|D. Bet on overall winner or loser                                   |\n";
		    cout << "----------------------------------------------------------------------\n";
		}
};
	