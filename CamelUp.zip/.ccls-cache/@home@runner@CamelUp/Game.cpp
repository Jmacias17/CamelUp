#include "Game.h"

void Game::displayCamelPositions()
{
	Camel currCamel;
	for (int i = 0; i < this->pieces; i++)
	{
		currCamel = this->getCamel(i);
		cout << currCamel.getColor() << " is at " << currCamel.getPosition() << "\n"; 
	}
}

void Game::start()
{
	this->setCamels();
	srand(time(0));
	int position;
	Camel currCamel;

	for (int i = 1; i < this->pieces; i++)
	{
		if (i < 5)
			position = 0 + ((rand() % 3) + 1); 
		else
			position = 16 - ((rand() % 3) + 1);
		
		currCamel = this->getCamel(i);
		currCamel.setPosition(position);
	}	

	displayCamelPositions();
}
		
		
char Game::getAction()
{
	char choice;
	Message::displayActions();
	
	cin >> choice;
	choice = toupper(choice);

	while (choice != 'A', 'B','C','D')
	{
		if ((choice >= 'A') && (choice <= 'D'))
		{
			return choice;
		}
		else
		{
			cout << "Not a valid action.\nTry again\n";
			cin >> choice;
			choice = toupper(choice);
		}
	}

	// In event of error
	return;
}



