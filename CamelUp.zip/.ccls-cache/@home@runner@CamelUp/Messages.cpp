#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>

class Message
	public string displayWelcome() 
	{}
