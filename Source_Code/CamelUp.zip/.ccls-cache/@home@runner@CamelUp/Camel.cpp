#include "Camel.h"

#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>

