#include <iostream>
using namespace std;
#include <ctype.h>
#include <cstring>
#include <string>
#include "CamelT"
#include <map>

class game
{
	private:
		std::map<std::camel

};
 